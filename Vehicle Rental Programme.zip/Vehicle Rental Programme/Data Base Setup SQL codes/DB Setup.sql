-- Vehicle Rental Management System DB setup SQL Codes

-- 1.Create vehicles table
CREATE TABLE vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id VARCHAR(50) UNIQUE NOT NULL,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    base_rate DOUBLE NOT NULL,
    vehicle_type VARCHAR(20) NOT NULL,
    type_specific_value DOUBLE NOT NULL, -- type_specific_value means Seats of car , CC of a Bike , Storage capasity (Kg) of a van
    is_available BOOLEAN DEFAULT TRUE    -- TRUE Means available , False Means Rented at that moument  
);

-- 2.Create rental income table
CREATE TABLE rental_income (
    id INT AUTO_INCREMENT PRIMARY KEY,
    total_income DOUBLE DEFAULT 0
);

-- 3.Insert starting income as a Rs. 0.00/- 
INSERT INTO rental_income (total_income) VALUES (0);


