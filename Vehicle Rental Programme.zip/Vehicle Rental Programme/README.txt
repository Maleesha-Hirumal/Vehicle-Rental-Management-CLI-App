VEHICLE RENTAL MANAGEMENT SYSTEM

Version	: 3.0
Module 	: CCS1303 - Object Oriented Programming  
Date	: 15 February 2026

TABLE OF CONTENTS

1. Project Overview
2. Features
3. System Requirements
4. How to Compile
5. How to Run
6. How to Use - Sample Menu Usage
7. Assumptions Made
8. Troubleshooting
9. File Structure

PROJECT OVERVIEW

A Vehicle Rental Management System demonstrating OOP concepts:
	Inheritance - Car, Bike, Van extend Vehicle
	Polymorphism - Vehicle references for all types
	Abstraction - Abstract Vehicle class
	Encapsulation - Private attributes with getters/setters

FEATURES

Add vehicles (Cars, Bikes, Vans)
View all vehicles  
Rent vehicles with automatic cost calculation 
Return vehicles
Search by ID and advanced filters 
Track rental income 
MySQL database integration 
Login system (root/root)

SYSTEM REQUIREMENTS
Required:
	Java JDK 
	MySQL Connector/J JAR: (Its already Attached on project file , you can find it on lib folder)
	Internet connection (for database)

Files Needs:
	Vehicle.java
	Car.java
	Bike.java
	Van.java
	RentalApp.java
	DatabaseManager.java
	Features.java
	mysql-connector-java-8.0.33.jar (Its already Attached on project file , you can find it on lib folder)

HOW TO add files:
	Open IntelliJ IDE
	Add the project

	Add the JDBC Jar file to project(steps are shown bellow):
		1.go to IntelliJ ide --> press ( ctrl + alt + shift + s )
		2.go to modules and then select dependencies 
		3.from there click on '+' mark and add the jar file from lib
		4.apply and ok 

HOW TO USE - SAMPLE MENU USAGE

1.LOGIN

Username		: root
Password		: root

Login successful! Welcome, root!

2.MAIN MENU

              MAIN MENU
  1. Add a Vehicle
  2. View All Vehicles
  3. Rent a Vehicle
  4. Return a Vehicle
  5. Search Vehicle by ID
  6. View Total Rental Income
  7. Advanced Search & Filtering
  8. Database Operations
  9. Logout & Exit

Enter choice (1-9): 



ADDING A CAR

Enter choice: 1

   ADD A NEW VEHICLE 
1. Car
2. Bike
3. Van
Select vehicle type (1-3): 1

Enter Vehicle ID: CAR001
Enter Brand: Toyota
Enter Model: Corolla
Enter Base Rate per Day (Rs.): 5000
Enter Number of Seats: 5

Vehicle added successfully!



VIEWING ALL VEHICLES

Enter choice: 2

   ALL VEHICLES 

Vehicle ID      		: CAR001
Brand           		: Toyota
Model          		 : Corolla
Base Rate/Day  	 : Rs. 5000.00
Vehicle Type   		 : CAR
Number of Seats 	: 5
Status         		 : AVAILABLE

Vehicle ID    	 	 : BIKE001
Brand			: Yamaha
Model			: R15
Base Rate/Day		: Rs. 2000.00
Vehicle Type   		 : BIKE
Engine Capacity 	: 150 CC
Status          		: AVAILABLE




RENTING A VEHICLE

Enter choice: 3

     RENT A VEHICLE 

Enter Vehicle ID: CAR001
Enter Number of Days: 3

     RENTAL SUMMARY 
Vehicle ID      : CAR001
Brand           : Toyota
Model           : Corolla
Rental Duration : 3 days
Total Cost      : Rs. 18000.00

Confirm rental? (yes/no): yes

Vehicle rented successfully!
Total Amount: Rs. 18000.00


Cost Calculation:

Base Cost = Rs. 5000 × 3 days = Rs. 15,000
Seat Cost = 5 seats × Rs. 200 × 3 days = Rs. 3,000
TOTAL = Rs. 18,000



RETURNING A VEHICLE

Enter choice: 4

     RETURN A VEHICLE

Enter Vehicle ID: CAR001

Vehicle returned successfully!


SEARCHING BY ID

Enter choice: 5

     SEARCH VEHICLE BY ID 

Enter Vehicle ID: BIKE001
Vehicle ID      : BIKE001
Brand           : Yamaha
Model           : R15
Base Rate/Day   : Rs. 2000.00
Vehicle Type    : BIKE
Engine Capacity : 150 CC
Status          : AVAILABLE




VIEWING TOTAL INCOME
Enter choice: 6

     TOTAL RENTAL INCOME 

Total Income: Rs. 18000.00



ADVANCED SEARCH - BY BRAND

Enter choice: 7

     ADVANCED SEARCH & FILTERING 
1. Search by Brand
2. Search by Availability
Enter choice: 1

Enter brand name: Toyota

   SEARCH RESULTS 
Found 1 vehicle(s):

Vehicle ID      	: CAR001
Brand           	: Toyota
Model           	: Corolla
Status          	: AVAILABLE



ADVANCED SEARCH - BY AVAILABILITY

Enter choice: 7

    ADVANCED SEARCH & FILTERING
1. Search by Brand
2. Search by Availability
Enter choice: 2

1. Available Vehicles
2. Rented Vehicles
Enter choice: 1

   SEARCH RESULTS
Found 2 vehicle(s):
[Shows all available vehicles]



SAVING TO DATABASE

Enter choice: 8

      DATABASE OPERATIONS
1. Save to Database
2. Load from Database
3. Back to Main Menu
Enter choice: 1

Saving to database...
Saved 3 vehicles successfully!




LOADING FROM DATABASE

Enter choice: 8

Enter choice: 2

Loaded 3 vehicles from database




EXITING

Enter choice: 9

Thank you for using the Vehicle Rental Management System!
Goodbye!



ASSUMPTIONS MADE

	USER INPUT data
	Vehicle IDs are unique (CAR001, BIKE001)
	IDs are case-insensitive (CAR001 = car001)
	All prices in LKR (Rs.)

BUSINESS LOGIC
	Vehicle can only be rented if AVAILABLE
	Vehicle can only be returned if RENTED
	No Expense (never decreases income table)
	Returning vehicle doesn't refund income
	No customer tracking

DATABASE
	Internet connection available
	'rental_income' table has a only 1 row 
	If database fails, program continues without it

AUTHENTICATION
	Single user (root/root)
	3 login attempts maximum
	Password is case-sensitive

VALIDATION
	All rates/values must be > 0
	Duplicate IDs not allowed
	Invalid input prompts for re-entry

NOT IMPLEMENTED
	Date and time 
	Customer management
	Rental history
	Late fees
	Multiple users
	GUI
	Payment processing

FILE STRUCTURE

Project
	Vehicle.java
		Car.java        
		Bike.java       
		Van.java      
	RentalApp.java      
	DatabaseManager.java 
	Features.java       




Thank you..!