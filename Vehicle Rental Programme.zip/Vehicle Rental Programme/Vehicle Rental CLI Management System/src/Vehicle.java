// AbstractClass
public abstract class Vehicle {
    private String vehicleId;
    private String brand;
    private String model;
    private double baseRatePerDay;
    private boolean isAvailable;

    public Vehicle(String vehicleId, String brand, String model, double baseRatePerDay) {
        this.vehicleId = vehicleId;
        this.brand = brand;
        this.model = model;
        this.baseRatePerDay = baseRatePerDay;
        this.isAvailable = true;
    }
    
    // Getters and Setters
    public String getVehicleId() {
        return vehicleId;
    }
    public String getBrand() {
        return brand;
    }
    public String getModel() {
        return model;
    }
    public double getBaseRatePerDay() {
        return baseRatePerDay;
    }
    public boolean isAvailable() {
        return isAvailable;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public void setBaseRatePerDay(double baseRatePerDay) {
        this.baseRatePerDay = baseRatePerDay;
    }
    public void setAvailable(boolean available) {
        this.isAvailable = available;
    }

    // 2.Show vehicle details
    public void displayDetails() {
        System.out.println("\n========================================");
        System.out.println("Vehicle ID      : " + vehicleId);
        System.out.println("Brand           : " + brand);
        System.out.println("Model           : " + model);
        System.out.println("Base Rate(Day)  : Rs. " + baseRatePerDay);
        System.out.println("Status          : " + (isAvailable ? "AVAILABLE" : "RENTED"));
    }
    
    // 3.Rent a vehicle
    public void rentVehicle() {
        if (isAvailable) {
            isAvailable = false;
            System.out.println("Vehicle rented successfully!");
        } else {
            System.out.println("Sorry, this vehicle is already rented.");
        }
    }
    
    // 4.Return this vehicle
    public void returnVehicle() {
        if (!isAvailable) {
            isAvailable = true;
            System.out.println("Vehicle returned successfully!");
        } else {
            System.out.println("This vehicle was not rented out.");
        }
    }

    public abstract double calculateRentalCost(int days);
}


