// Subclass
public class Car extends Vehicle {
    private int numberOfSeats;

    public Car(String vehicleId, String brand, String model, double baseRatePerDay, int numberOfSeats) {
        super(vehicleId, brand, model, baseRatePerDay);
        this.numberOfSeats = numberOfSeats;
    }
    
    // Getters and Setters
    public int getNumberOfSeats() {
        return numberOfSeats;
    }
    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Vehicle Type    : CAR");
        System.out.println("Number of Seats : " + numberOfSeats);
        System.out.println("========================================");
    }
    
    // calculculation (Rental cost of Car)
    @Override
    public double calculateRentalCost(int days) {
        double baseCost = getBaseRatePerDay() * days;
        double seatCost = numberOfSeats * 200 * days;
        return baseCost + seatCost;
    }
}













