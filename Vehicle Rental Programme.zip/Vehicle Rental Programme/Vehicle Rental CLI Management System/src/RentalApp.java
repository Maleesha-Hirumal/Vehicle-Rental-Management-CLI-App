// Main Application

import java.util.ArrayList;
import java.util.Scanner;

public class RentalApp {
    private static ArrayList<Vehicle> vehicleList = new ArrayList<>();
    private static double totalRentalIncome = 0.0;
    private static Scanner scanner = new Scanner(System.in);

    // Login Usernames and Passwords
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
        if (!performLogin()) {
            return;
        }

        // Load data from database
        Object[] data = DatabaseManager.loadData();
        vehicleList = (ArrayList<Vehicle>) data[0];
        totalRentalIncome = (double) data[1];

        // Main menu
        boolean running = true;
        while (running) {
            displayMenu();
            int choice = getValidChoice();

            switch (choice) {
                case 1: addVehicle(); break;
                case 2: viewAllVehicles(); break;
                case 3: rentVehicle(); break;
                case 4: returnVehicle(); break;
                case 5: searchVehicleById(); break;
                case 6: viewTotalIncome(); break;
                case 7: Features.advancedSearch(vehicleList, scanner); break;
                case 8: databaseMenu(); break;
                case 9: resetMonthlyIncome(); break;
                case 10:
                    System.out.println("\nLogging out... Goodbye!\n");
                    running = false;
                    break;
                default:
                    System.out.println("\nInvalid choice!\n");
            }
        }

        scanner.close();
    }

    // Login menu
    private static boolean performLogin() {
        boolean loggedIn = false;
        int attempts = 0;

        System.out.println("██╗    ██╗███████╗██╗      ██████╗ ██████╗ ███╗   ███╗███████╗      ██╗");
        System.out.println("██║    ██║██╔════╝██║     ██╔════╝██╔═══██╗████╗ ████║██╔════╝      ██║");
        System.out.println("██║ █╗ ██║█████╗  ██║     ██║     ██║   ██║██╔████╔██║█████╗        ██║");
        System.out.println("██║███╗██║██╔══╝  ██║     ██║     ██║   ██║██║╚██╔╝██║██╔══╝        ╚═╝");
        System.out.println("╚███╔███╔╝███████╗███████╗╚██████╗╚██████╔╝██║ ╚═╝ ██║███████╗██╗██╗██╗");
        System.out.println(" ╚══╝╚══╝ ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝╚═╝╚═╝╚═╝");

        System.out.println("\n╔════════════════════════════════════════════════╗");
        System.out.println("║        VEHICLE RENTAL MANAGEMENT SYSTEM        ║");
        System.out.println("║                LOGIN REQUIRED                  ║");
        System.out.println("╚════════════════════════════════════════════════╝\n");

        while (!loggedIn && attempts < 3) {
            System.out.print("Enter Username: ");
            String inputUsername = scanner.nextLine();
            System.out.print("Enter Password: ");
            String inputPassword = scanner.nextLine();

            if (inputUsername.equals(USERNAME) && inputPassword.equals(PASSWORD)) {
                loggedIn = true;
                System.out.println("\nLogin successful! Welcome Back, " + USERNAME + "!\n");
            } else {
                attempts++;
                if (attempts < 3) {
                    System.out.println("\nInvalid Login credentials! Try again. (" + (3 - attempts) + " attempts are left)\n");
                } else {
                    System.out.println("\nToo many failed attempts. Exiting from the Program ...\n");
                }
            }
        }
        return loggedIn;
    }

    // Application Menu
    private static void displayMenu() {
        System.out.println("\n┌────────────────────────────────────────┐");
        System.out.println("│               MAIN MENU                │");
        System.out.println("├────────────────────────────────────────┤");
        System.out.println("│  1. Add a Vehicle                      │");
        System.out.println("│  2. View All Vehicles                  │");
        System.out.println("│  3. Rent a Vehicle                     │");
        System.out.println("│  4. Return a Vehicle                   │");
        System.out.println("│  5. Search Vehicle by ID               │");
        System.out.println("│  6. View Total Rental Income           │");
        System.out.println("│  7. Advanced Search & Filtering        │");
        System.out.println("│  8. Database Operations                │");
        System.out.println("│  9. Reset Monthly Income               │");
        System.out.println("│ 10. Logout & Exit                      │");
        System.out.println("└────────────────────────────────────────┘");
        System.out.print("Enter choice (1-10): ");
    }

    // Getting Choice
    private static int getValidChoice() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Enter a valid number: ");
            }
        }
    }

    // 1.Add vehicle
    private static void addVehicle() {
        while (true) {
            System.out.println("\n=== ADD A NEW VEHICLE ===");
            System.out.println("1. Car");
            System.out.println("2. Bike");
            System.out.println("3. Van");
            System.out.println("4. Back to Main Menu");
            System.out.print("Select vehicle type (1-4): ");
            int type = getValidChoice();

            if (type == 4) {
                return;
            }

            try {
                System.out.print("\nVehicle ID: ");
                String id = scanner.nextLine().trim();
                if (isVehicleIdExists(id)) {
                    System.out.println("Error: Vehicle ID already exists on the database.!");
                    continue;
                }

                System.out.print("Brand: ");
                String brand = scanner.nextLine().trim();
                System.out.print("Model: ");
                String model = scanner.nextLine().trim();
                System.out.print("Base Rate per Day (Rs.): ");
                double rate = Double.parseDouble(scanner.nextLine());

                if (rate <= 0) {
                    System.out.println("Error: Rate must be greater than Rs.0.00 !");
                    continue;
                }
                Vehicle vehicle = null;

                // Vehicle Details
                switch (type) {
                    case 1:
                        System.out.print("Number of Seats: ");
                        int seats = Integer.parseInt(scanner.nextLine());
                        if (seats <= 0) {
                            System.out.println("Error: Seats must be greater than 0!");
                            continue;
                        }
                        vehicle = new Car(id, brand, model, rate, seats);
                        break;

                    case 2:
                        System.out.print("Engine Capacity(CC): ");
                        int cc = Integer.parseInt(scanner.nextLine());
                        if (cc <= 0) {
                            System.out.println("Error: Engine capacity must be greater than 0!");
                            continue;
                        }
                        vehicle = new Bike(id, brand, model, rate, cc);
                        break;

                    case 3:
                        System.out.print("Cargo Capacity(Kg): ");
                        double cargo = Double.parseDouble(scanner.nextLine());
                        if (cargo <= 0) {
                            System.out.println("Error: Cargo capacity must be greater than 0!");
                            continue;
                        }
                        vehicle = new Van(id, brand, model, rate, cargo);
                        break;

                    default:
                        System.out.println("Invalid vehicle type!");
                        continue;
                }

                vehicleList.add(vehicle);
                System.out.println("\nVehicle added successfully!");
                return;

            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid input!");
            }
        }
    }

    // 2. View all registerd vehicles
    private static void viewAllVehicles() {
        while (true) {
            System.out.println("\n=== ALL VEHICLES ===");
            if (vehicleList.isEmpty()) {
                System.out.println("No vehicles in the system.");
            } else {
                System.out.println("Total Vehicles: " + vehicleList.size());
                for (Vehicle v : vehicleList) {
                    v.displayDetails();
                }
            }
            System.out.println("\n1. Back to Main Menu");
            System.out.print("Enter choice: ");
            int choice = getValidChoice();
            if (choice == 1) {
                return;
            }
        }
    }

    // 3.Rent vehicle
    private static void rentVehicle() {
        while (true) {
            System.out.println("\n=== RENT A VEHICLE ===");
            if (vehicleList.isEmpty()) {
                System.out.println("No vehicles available Right Now.");
                System.out.println("\n1. Back to Main Menu");
                System.out.print("Enter choice: ");
                int choice = getValidChoice();
                if (choice == 1) {
                    return;
                }
                continue;
            }
            System.out.println("Enter Vehicle ID (or type '0' to go back): ");
            String id = scanner.nextLine().trim();
            if (id.equals("0")) {
                return;
            }
            Vehicle vehicle = findVehicleById(id);
            if (vehicle == null) {
                System.out.println("Vehicle not found!");
                continue;
            }
            if (!vehicle.isAvailable()) {
                System.out.println("This vehicle is already rented!");
                continue;
            }
            try {
                System.out.print("Number of rental days: ");
                int days = Integer.parseInt(scanner.nextLine());
                if (days <= 0) {
                    System.out.println("Error: Days must be greater than 0!");
                    continue;
                }
                double cost = vehicle.calculateRentalCost(days);
                System.out.println("\n--- RENTAL SUMMARY ---");
                vehicle.displayDetails();
                System.out.println("Rental Duration : " + days + " days");
                System.out.println("Total Cost      : Rs. " + String.format("%.2f", cost));
                System.out.print("\nConfirm rental? (yes/no): ");
                String confirm = scanner.nextLine().trim().toLowerCase();

                if (confirm.equals("yes") || confirm.equals("y")) {
                    vehicle.rentVehicle();
                    totalRentalIncome += cost;
                    System.out.println("Total Amount: Rs. " + String.format("%.2f", cost));
                    return;
                } else {
                    System.out.println("Rental cancelled.");
                    return;
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid number!");
            }
        }
    }

    // 4.Return vehicle
    private static void returnVehicle() {
        while (true) {
            System.out.println("\n=== RETURN A VEHICLE ===");
            if (vehicleList.isEmpty()) {
                System.out.println("No vehicles in the system.");
                System.out.println("\n1. Back to Main Menu");
                System.out.print("Enter choice: ");
                int choice = getValidChoice();
                if (choice == 1) {
                    return;
                }
                continue;
            }
            System.out.println("Enter Vehicle ID (or type '0' to go back): ");
            String id = scanner.nextLine().trim();
            if (id.equals("0")) {
                return;
            }
            Vehicle vehicle = findVehicleById(id);
            if (vehicle == null) {
                System.out.println("Vehicle not found!");
                continue;
            }
            if (vehicle.isAvailable()) {
                System.out.println("This vehicle is not currently rented!");
                continue;
            }
            vehicle.returnVehicle();
            return;
        }
    }

    // 5.Search vehicle by ID
    private static void searchVehicleById() {
        while (true) {
            System.out.println("\n=== SEARCH VEHICLE BY ID ===");
            if (vehicleList.isEmpty()) {
                System.out.println("No vehicles in the system.");
                System.out.println("\n1. Back to Main Menu");
                System.out.print("Enter choice: ");
                int choice = getValidChoice();
                if (choice == 1) {
                    return;
                }
                continue;
            }
            System.out.println("Enter Vehicle ID (or type '0' to go back): ");
            String id = scanner.nextLine().trim();
            if (id.equals("0")) {
                return;
            }
            Vehicle vehicle = findVehicleById(id);
            if (vehicle == null) {
                System.out.println("Vehicle not found!");
            } else {
                System.out.println("\nVehicle Found:");
                vehicle.displayDetails();
                return;
            }
        }
    }

    // 6.Total rental income
    private static void viewTotalIncome() {
        while (true) {
            System.out.println("\n=== TOTAL RENTAL INCOME ===");
            System.out.println("Total Income: Rs. " + String.format("%.2f", totalRentalIncome));
            System.out.println("\n1. Back to Main Menu");
            System.out.print("Enter choice: ");
            int choice = getValidChoice();
            if (choice == 1) {
                return;
            }
        }
    }

    // 9.Reset monthly income
    private static void resetMonthlyIncome() {
        while (true) {
            System.out.println("\n=== RESET MONTHLY INCOME ===");
            System.out.println("Current Total Income: Rs. " + String.format("%.2f", totalRentalIncome));
            System.out.println("\nWARNING: This will reset the income to Rs. 0.00");
            System.out.println("This is typically done at the end of each month.");
            System.out.println("\n1. Confirm Reset");
            System.out.println("2. Back to Main Menu");
            System.out.print("Enter choice (1-2): ");
            int choice = getValidChoice();

            if (choice == 1) {
                totalRentalIncome = 0.0;
                System.out.println("\nMonthly income has been reset to Rs. 0.00");
                System.out.println("Don't forget to save to database!");
                return;
            } else if (choice == 2) {
                return;
            } else {
                System.out.println("Invalid choice!");
            }
        }
    }

    // 8. Db operations
    private static void databaseMenu() {
        System.out.println("\n=== DATABASE OPERATIONS ===");
        System.out.println("1. Save to Database");
        System.out.println("2. Load from Database");
        System.out.println("3. Back to Main Menu");
        System.out.print("Enter choice (1-3): ");
        int choice = getValidChoice();

        switch (choice) {
            case 1:
                DatabaseManager.saveData(vehicleList, totalRentalIncome);
                break;
            case 2:
                Object[] data = DatabaseManager.loadData();
                vehicleList = (ArrayList<Vehicle>) data[0];
                totalRentalIncome = (double) data[1];
                break;
            case 3:
                return;
            default:
                System.out.println("Invalid choice!");
        }
    }

    // Check if vehicle id already saved or not
    private static boolean isVehicleIdExists(String id) {
        for (Vehicle v : vehicleList) {
            if (v.getVehicleId().equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }

    // Find vehicles by id
    private static Vehicle findVehicleById(String id) {
        for (Vehicle v : vehicleList) {
            if (v.getVehicleId().equalsIgnoreCase(id)) {
                return v;
            }
        }
        return null;
    }
}













