// DataBase Manager
import java.sql.*;
import java.util.ArrayList;

public class DatabaseManager {
    // Database credentials for InfinityFree
    private static final String DB_URL = "jdbc:mysql://sql12.freesqldatabase.com:3306/sql12816676";
    private static final String DB_USER = "sql12816676";
    private static final String DB_PASSWORD = "XKjHMC8M61";

    // Add all vehicles and income to database
        public static void saveData(ArrayList<Vehicle> vehicleList, double totalIncome) {
        System.out.println("\nSaving to database...");
        Connection conn = null;
        try {
            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            // Delete old data
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM vehicles");
            stmt.close();
            // Insert vehicles
            String sql = "INSERT INTO vehicles (vehicle_id, brand, model, base_rate, vehicle_type, type_specific_value, is_available) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            
            for (Vehicle v : vehicleList) {
                pstmt.setString(1, v.getVehicleId());
                pstmt.setString(2, v.getBrand());
                pstmt.setString(3, v.getModel());
                pstmt.setDouble(4, v.getBaseRatePerDay());
                if (v instanceof Car) {
                    pstmt.setString(5, "CAR");
                    pstmt.setDouble(6, ((Car) v).getNumberOfSeats());
                } else if (v instanceof Bike) {
                    pstmt.setString(5, "BIKE");
                    pstmt.setDouble(6, ((Bike) v).getEngineCapacityCC());
                } else if (v instanceof Van) {
                    pstmt.setString(5, "VAN");
                    pstmt.setDouble(6, ((Van) v).getCargoCapacityKg());
                }
                pstmt.setBoolean(7, v.isAvailable());
                pstmt.executeUpdate();
            }
            pstmt.close();
            
            // Update income table
            stmt = conn.createStatement();
            stmt.executeUpdate("UPDATE rental_income SET total_income = " + totalIncome);
            stmt.close();
            System.out.println("Saved " + vehicleList.size() + " vehicles successfully!");
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
            }
        }
    }
    
    // Load all vehicles and income from database to Local Program
    public static Object[] loadData() {
        ArrayList<Vehicle> vehicleList = new ArrayList<>();
        double totalIncome = 0.0;
        Connection conn = null;
        
        try {
            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            // Load vehicles
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM vehicles");
            while (rs.next()) {
                String id = rs.getString("vehicle_id");
                String brand = rs.getString("brand");
                String model = rs.getString("model");
                double rate = rs.getDouble("base_rate");
                String type = rs.getString("vehicle_type");
                double value = rs.getDouble("type_specific_value");
                boolean available = rs.getBoolean("is_available");
                Vehicle vehicle = null;
                if (type.equals("CAR")) {
                    vehicle = new Car(id, brand, model, rate, (int) value);
                } else if (type.equals("BIKE")) {
                    vehicle = new Bike(id, brand, model, rate, (int) value);
                } else if (type.equals("VAN")) {
                    vehicle = new Van(id, brand, model, rate, value);
                }
                if (vehicle != null) {
                    vehicle.setAvailable(available);
                    vehicleList.add(vehicle);
                }
            }
            rs.close();
            stmt.close();

            // Load income from DB
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT total_income FROM rental_income");
            if (rs.next()) {
                totalIncome = rs.getDouble("total_income");
            }
            rs.close();
            stmt.close();
            
            if (vehicleList.size() > 0) {
                System.out.println("Loaded " + vehicleList.size() + " vehicles from database");
            }
        } catch (SQLException e) {
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
            }
        }
        
        return new Object[]{vehicleList, totalIncome};
    }
}






