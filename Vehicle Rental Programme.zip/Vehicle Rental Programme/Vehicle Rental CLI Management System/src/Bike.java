// Subclass
public class Bike extends Vehicle {
    private int engineCapacityCC;

    public Bike(String vehicleId, String brand, String model, double baseRatePerDay, int engineCapacityCC) {
        super(vehicleId, brand, model, baseRatePerDay);
        this.engineCapacityCC = engineCapacityCC;
    }
    
    // Getters and Setters
    public int getEngineCapacityCC() {
        return engineCapacityCC;
    }
    public void setEngineCapacityCC(int engineCapacityCC) {
        this.engineCapacityCC = engineCapacityCC;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Vehicle Type    : BIKE");
        System.out.println("Engine Capacity : " + engineCapacityCC + " CC");
        System.out.println("========================================");
    }
    
    // Calculaton (Rental cost of a Bike)
    @Override
    public double calculateRentalCost(int days) {
        double baseCost = getBaseRatePerDay() * days;
        double engineCost = engineCapacityCC * 0.5 * days;
        return baseCost + engineCost;
    }
}










