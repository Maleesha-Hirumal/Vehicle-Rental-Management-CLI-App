// Subclass
public class Van extends Vehicle {
    private double cargoCapacityKg;

    public Van(String vehicleId, String brand, String model, double baseRatePerDay, double cargoCapacityKg) {
        super(vehicleId, brand, model, baseRatePerDay);
        this.cargoCapacityKg = cargoCapacityKg;
    }
    
    // Getters and Setters
    public double getCargoCapacityKg() {
        return cargoCapacityKg;
    }
    public void setCargoCapacityKg(double cargoCapacityKg) {
        this.cargoCapacityKg = cargoCapacityKg;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Vehicle Type    : VAN");
        System.out.println("Cargo Capacity  : " + cargoCapacityKg + " Kg");
        System.out.println("========================================");
    }
    
    // calculation ( Rental cost of a Van )
    @Override
    public double calculateRentalCost(int days) {
        double baseCost = getBaseRatePerDay() * days;
        double cargoCost = cargoCapacityKg * 0.2 * days;
        return baseCost + cargoCost;
    }
}










