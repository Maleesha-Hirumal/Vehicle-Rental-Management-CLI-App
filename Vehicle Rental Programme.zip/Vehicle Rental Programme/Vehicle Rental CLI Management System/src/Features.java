// Features Class
import java.util.ArrayList;
import java.util.Scanner;

// 7. Advanced Search & Filtering Feature
public class Features {
    public static void advancedSearch(ArrayList<Vehicle> vehicleList, Scanner scanner) {
        while (true) {
            System.out.println("\n=== ADVANCED SEARCH & FILTERING ===");
            if (vehicleList.isEmpty()) {
                System.out.println("No vehicles in system.");
                System.out.println("\n1. Back to Main Menu");
                System.out.print("Enter choice: ");
                int backChoice = getValidChoice(scanner);
                if (backChoice == 1) {
                    return;
                }
                continue;
            }
            System.out.println("1. Search by Brand");
            System.out.println("2. Search by Availability");
            System.out.println("3. Back to Main Menu");
            System.out.print("Enter choice (1-3): ");
            int choice = getValidChoice(scanner);
            
            if (choice == 3) {
                return;
            }
            
            ArrayList<Vehicle> results = new ArrayList<>();
            try {
                switch (choice) {
                    case 1:
                        searchByBrand(vehicleList, scanner, results);
                        break;
                    case 2:
                        searchByAvailability(vehicleList, scanner, results);
                        break;
                    default:
                        System.out.println("Invalid choice!");
                        continue;
                }
                displayResults(results);
            } catch (Exception e) {
                System.out.println("Invalid input!");
            }
        }
    }
    
    // Search by brand
    private static void searchByBrand(ArrayList<Vehicle> vehicleList, Scanner scanner, ArrayList<Vehicle> results) {
        System.out.print("Enter brand name: ");
        String brand = scanner.nextLine().trim();
        for (Vehicle v : vehicleList) {
            if (v.getBrand().equalsIgnoreCase(brand)) {
                results.add(v);
            }
        }
    }
    
    // Search by availability
    private static void searchByAvailability(ArrayList<Vehicle> vehicleList, Scanner scanner, ArrayList<Vehicle> results) {
        System.out.println("1. Available Vehicles");
        System.out.println("2. Rented Vehicles");
        System.out.print("Enter choice: ");
        int availChoice = getValidChoice(scanner);
        boolean showAvailable = (availChoice == 1);
        for (Vehicle v : vehicleList) {
            if (v.isAvailable() == showAvailable) {
                results.add(v);
            }
        }
    }
    
    // Display the vehicles
    private static void displayResults(ArrayList<Vehicle> results) {
        if (results.isEmpty()) {
            System.out.println("\nNo vehicles found.");
        } else {
            System.out.println("\nFound " + results.size() + " vehicle(s):");
            for (Vehicle v : results) {
                v.displayDetails();
            }
        }
    }
    
    // Validate number input
    private static int getValidChoice(Scanner scanner) {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Enter a valid number: ");
            }
        }
    }
}









